def registrasi_gadge (brand, tipe, harga, sn, status):
    if harga > 1000000:
        print("harga tidak valid")
        return None
    if len(sn) < 5:
        print("serial nomor tidak valid")
        return None
    return{
        'merk': merk,
        'tipe': tipe,
        'harga': harga,
        'sn': sn,


    }
    

inventaris = []

for i in range(3):
    merk = input("masukan merk gadget: ")
    tipe = input("masukan tipe gadget: ")
    harga = int(input("masukan harga gadget: "))
    sn = input("masukan serial nomor: ")
    gadget = registrasi_gadge(merk, tipe, harga, sn)

registrasi_gadge = {
(f"merk{merk}, tipe{tipe}, harga{harga}, sn{sn}, status{status}")
}

print(registrasi_gadge)